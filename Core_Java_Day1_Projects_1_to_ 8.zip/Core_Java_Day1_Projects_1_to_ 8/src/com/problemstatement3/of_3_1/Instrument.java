package com.problemstatement3.of_3_1;

public abstract class Instrument {
	public abstract void play();
}
